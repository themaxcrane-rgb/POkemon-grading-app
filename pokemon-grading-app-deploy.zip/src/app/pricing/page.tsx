'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Check,
  Star,
  Zap,
  TrendingUp,
  Award,
  Shield,
  Clock,
  CreditCard,
} from 'lucide-react';

const plans = [
  {
    name: 'Free',
    price: '$0',
    period: '/month',
    description: 'Perfect for casual collectors',
    features: [
      '3 analyses per month',
      'Basic card grading',
      'Email notifications',
      'Community access',
    ],
    cta: 'Get Started',
    popular: false,
  },
  {
    name: 'Pro',
    price: '$9.99',
    period: '/month',
    description: 'For serious collectors',
    features: [
      'Unlimited analyses',
      'Advanced AI grading',
      'High-resolution previews',
      'Export to PDF',
      'Priority support',
      'Comparison tools',
    ],
    cta: 'Start Free Trial',
    popular: true,
  },
  {
    name: 'Elite',
    price: '$24.99',
    period: '/month',
    description: 'For professional traders',
    features: [
      'Everything in Pro',
      'API access',
      'Bulk analysis',
      'Market price integration',
      'Dedicated support',
      'Early access to features',
    ],
    cta: 'Start Free Trial',
    popular: false,
  },
];

export default function PricingPage() {
  const [email, setEmail] = useState('');
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('monthly');

  const handleSubscribe = async (plan: typeof plans[0]) => {
    try {
      const response = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email,
          subscriptionType: billingCycle,
        }),
      });

      const data = await response.json();

      if (data.success && data.sessionId) {
        window.location.href = `https://checkout.stripe.com/c/pay/${data.sessionId}`;
      }
    } catch (error) {
      console.error('Subscription error:', error);
      alert('Failed to create checkout session. Please try again.');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-16 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-5xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent mb-4">
            Choose Your Plan
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Invest in your card collection with confidence
          </p>

          {/* Billing Toggle */}
          <div className="flex items-center justify-center gap-4 mb-8">
            <span className={`text-sm ${billingCycle === 'monthly' ? 'text-blue-600 font-semibold' : 'text-gray-500'}`}>
              Monthly
            </span>
            <button
              onClick={() => setBillingCycle(prev => prev === 'monthly' ? 'yearly' : 'monthly')}
              className="relative w-16 h-8 bg-blue-600 rounded-full p-1 transition-colors hover:bg-blue-700"
            >
              <div className={`w-6 h-6 bg-white rounded-full shadow-md transform transition-transform ${billingCycle === 'yearly' ? 'translate-x-8' : ''}`}></div>
            </button>
            <span className={`text-sm ${billingCycle === 'yearly' ? 'text-blue-600 font-semibold' : 'text-gray-500'}`}>
              Yearly (-20%)
            </span>
          </div>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {plans.map((plan) => (
            <Card
              key={plan.name}
              className={`relative p-8 ${
                plan.popular
                  ? 'border-2 border-blue-500 shadow-2xl scale-105'
                  : 'shadow-lg'
              } bg-white hover:shadow-xl transition-all`}
            >
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <Badge className="bg-blue-600 text-white px-4 py-1">
                    <Star className="w-4 h-4 mr-1" />
                    Most Popular
                  </Badge>
                </div>
              )}

              <div className="text-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{plan.name}</h3>
                <p className="text-gray-600 mb-4">{plan.description}</p>
                <div className="flex items-baseline justify-center">
                  <span className="text-5xl font-bold text-blue-600">{plan.price}</span>
                  <span className="text-gray-600 ml-2">{plan.period}</span>
                </div>
              </div>

              <ul className="space-y-4 mb-8">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start">
                    <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0 mt-0.5" />
                    <span className="text-gray-700">{feature}</span>
                  </li>
                ))}
              </ul>

              <Button
                className="w-full h-12 text-lg"
                onClick={() => handleSubscribe(plan)}
              >
                {plan.cta}
              </Button>
            </Card>
          ))}
        </div>

        {/* Features Comparison */}
        <div className="mt-16 bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-3xl font-bold text-center mb-8">
            Why Choose Pokémon Card Grading Assistant?
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                icon: Award,
                title: 'Accurate AI Analysis',
                description: 'Our AI uses PSA grading standards to predict grades with 85%+ accuracy',
              },
              {
                icon: Shield,
                title: 'Save Money',
                description: 'Avoid grading fees for cards that won\'t get a high grade',
              },
              {
                icon: Zap,
                title: 'Lightning Fast',
                description: 'Get predictions in seconds, not days',
              },
              {
                icon: TrendingUp,
                title: 'Track Your Collection',
                description: 'History of all analyses with detailed breakdowns',
              },
              {
                icon: Clock,
                title: '24/7 Access',
                description: 'Grade cards anytime, anywhere',
              },
              {
                icon: CreditCard,
                title: 'Secure Payments',
                description: 'Industry-standard encryption and data protection',
              },
            ].map((feature, index) => (
              <Card key={index} className="p-6 text-center">
                <feature.icon className="w-12 h-12 text-blue-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
