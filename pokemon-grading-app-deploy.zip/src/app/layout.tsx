export const metadata = {
  title: 'Pokémon Card Grading Assistant | AI-Powered PSA Grade Prediction',
  description: 'Upload your Pokémon cards and get AI-powered PSA/Beckett grade predictions. Save money on grading fees with accurate analysis!',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
        {children}
      </body>
    </html>
  );
}
