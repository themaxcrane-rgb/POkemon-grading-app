'use client';

import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  BarChart3, 
  TrendingUp, 
  Download, 
  Award,
  Filter,
  Search,
  Calendar
} from 'lucide-react';

interface Analysis {
  id: number;
  cardName: string;
  setName: string;
  predictedGrade: number;
  confidenceScore: number;
  analysisTimestamp: string;
  isPaid: boolean;
  centeringScore: number;
  cornerScore: number;
  edgeScore: number;
  surfaceScore: number;
}

export default function Dashboard() {
  const [analyses, setAnalyses] = useState<Analysis[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterGrade, setFilterGrade] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    // Fetch user analyses
    fetch('/api/analyses')
      .then(res => res.json())
      .then(data => {
        setAnalyses(data.analyses || []);
        setLoading(false);
      })
      .catch(err => {
        console.error('Failed to load analyses:', err);
        setLoading(false);
      });
  }, []);

  const filteredAnalyses = analyses.filter(a => {
    const matchesGrade = filterGrade === 'all' || a.predictedGrade.toString() === filterGrade;
    const matchesSearch = a.cardName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         a.set_name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesGrade && matchesSearch;
  });

  const stats = {
    total: analyses.length,
    tenGrades: analyses.filter(a => a.predictedGrade === 10).length,
    avgGrade: analyses.length > 0 
      ? Math.round(analyses.reduce((sum, a) => sum + a.predictedGrade, 0) / analyses.length)
      : 0,
    paid: analyses.filter(a => a.isPaid).length,
  };

  const exportToCSV = () => {
    const csv = [
      ['Card Name', 'Set', 'Grade', 'Confidence', 'Date', 'Paid'],
      ...filteredAnalyses.map(a => [
        a.cardName,
        a.set_name,
        a.predictedGrade,
        a.confidenceScore,
        new Date(a.analysisTimestamp).toLocaleDateString(),
        a.isPaid ? 'Yes' : 'No'
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pokemon-grading-export-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            🎴 My Card Grading History
          </h1>
          <p className="text-gray-600 mt-2">
            Track all your Pokémon card grading analyses
          </p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <Card className="p-6 bg-white shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Analyses</p>
                <p className="text-3xl font-bold text-blue-600">{stats.total}</p>
              </div>
              <BarChart3 className="w-12 h-12 text-blue-400" />
            </div>
          </Card>

          <Card className="p-6 bg-white shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Perfect 10s</p>
                <p className="text-3xl font-bold text-green-600">{stats.tenGrades}</p>
              </div>
              <Award className="w-12 h-12 text-green-400" />
            </div>
          </Card>

          <Card className="p-6 bg-white shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Average Grade</p>
                <p className="text-3xl font-bold text-purple-600">{stats.avgGrade}</p>
              </div>
              <TrendingUp className="w-12 h-12 text-purple-400" />
            </div>
          </Card>

          <Card className="p-6 bg-white shadow-lg">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Paid Analyses</p>
                <p className="text-3xl font-bold text-orange-600">{stats.paid}</p>
              </div>
              <Calendar className="w-12 h-12 text-orange-400" />
            </div>
          </Card>
        </div>

        {/* Filters */}
        <Card className="p-4 mb-6">
          <div className="flex flex-wrap gap-4 items-center">
            <div className="flex items-center gap-2">
              <Search className="w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search cards or sets..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <select
                value={filterGrade}
                onChange={(e) => setFilterGrade(e.target.value)}
                className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">All Grades</option>
                <option value="10">Grade 10</option>
                <option value="9">Grade 9</option>
                <option value="8">Grade 8</option>
                <option value="7">Grade 7</option>
                <option value="6">Grade 6</option>
                <option value="5">Grade 5 or below</option>
              </select>
            </div>

            <Button onClick={exportToCSV} variant="outline" className="flex items-center gap-2">
              <Download className="w-4 h-4" />
              Export CSV
            </Button>
          </div>
        </Card>

        {/* Analyses List */}
        <Card className="overflow-hidden">
          {loading ? (
            <div className="p-8 text-center">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
              <p className="mt-4 text-gray-600">Loading your analyses...</p>
            </div>
          ) : filteredAnalyses.length === 0 ? (
            <div className="p-8 text-center">
              <p className="text-gray-500 text-lg">No analyses yet</p>
              <p className="text-gray-400 mt-2">Upload a card to get your first prediction!</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Card</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Set</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Grade</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Confidence</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Subgrades</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {filteredAnalyses.map((analysis) => (
                    <tr key={analysis.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <div className="font-medium text-gray-900">{analysis.cardName}</div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-600">{analysis.set_name}</div>
                      </td>
                      <td className="px-6 py-4">
                        <Badge 
                          className={`font-bold ${
                            analysis.predictedGrade === 10 ? 'bg-green-100 text-green-800' :
                            analysis.predictedGrade >= 9 ? 'bg-blue-100 text-blue-800' :
                            analysis.predictedGrade >= 8 ? 'bg-purple-100 text-purple-800' :
                            'bg-gray-100 text-gray-800'
                          }`}
                        >
                          PSA {analysis.predictedGrade}
                        </Badge>
                      </td>
                      <td className="px-6 py-4">
                        <span className="text-sm text-gray-600">{(analysis.confidenceScore * 100).toFixed(0)}%</span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex gap-2 text-xs">
                          <span className="text-gray-500">C: {analysis.centeringScore.toFixed(1)}</span>
                          <span className="text-gray-500">Co: {analysis.cornerScore.toFixed(1)}</span>
                          <span className="text-gray-500">E: {analysis.edgeScore.toFixed(1)}</span>
                          <span className="text-gray-500">S: {analysis.surfaceScore.toFixed(1)}</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="text-sm text-gray-600">
                          {new Date(analysis.analysisTimestamp).toLocaleDateString()}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </Card>
      </div>
    </div>
  );
}
