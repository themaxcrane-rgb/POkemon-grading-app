import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { query } from '@/lib/database';

// Analysis request schema
const analyzeSchema = z.object({
  cardName: z.string().min(1, 'Card name is required'),
  setName: z.string().min(1, 'Set name is required'),
  image: z.string().url('Invalid image URL'),
  userId: z.string().optional(),
});

// AI grading criteria (based on PSA standards)
const PSA_CENTRING = {
  PERFECT: { min: 0, max: 0.25, grade: 10 },
  EXCELLENT: { min: 0.26, max: 0.50, grade: 9 },
  GOOD: { min: 0.51, max: 0.75, grade: 8 },
  FAIR: { min: 0.76, max: 1.00, grade: 7 },
  POOR: { min: 1.01, max: 2.00, grade: 6 },
};

const PSA_CORNERS = {
  PERFECT: { min: 0, max: 0, grade: 10 },
  EXCELLENT: { min: 0.01, max: 0.10, grade: 9 },
  GOOD: { min: 0.11, max: 0.25, grade: 8 },
  FAIR: { min: 0.26, max: 0.50, grade: 7 },
  POOR: { min: 0.51, max: 1.00, grade: 6 },
};

const PSA_EDGES = {
  PERFECT: { min: 0, max: 0, grade: 10 },
  EXCELLENT: { min: 0.01, max: 0.15, grade: 9 },
  GOOD: { min: 0.16, max: 0.30, grade: 8 },
  FAIR: { min: 0.31, max: 0.50, grade: 7 },
  POOR: { min: 0.51, max: 1.00, grade: 6 },
};

const PSA_SURFACE = {
  PERFECT: { min: 0, max: 0, grade: 10 },
  EXCELLENT: { min: 0.01, max: 0.10, grade: 9 },
  GOOD: { min: 0.11, max: 0.25, grade: 8 },
  FAIR: { min: 0.26, max: 0.50, grade: 7 },
  POOR: { min: 0.51, max: 1.00, grade: 6 },
};

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { cardName, setName, image, userId } = analyzeSchema.parse(body);

    // Simulate AI analysis (replace with actual AI service)
    const analysis = await performAIAnalysis(image);

    // Save analysis to database
    const result = await query(
      `INSERT INTO analyses (card_name, set_name, image_url, predicted_grade, confidence_score, centering_score, corner_score, edge_score, surface_score, is_paid) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
      [cardName, setName, image, analysis.grade, analysis.confidence, analysis.centering, analysis.corners, analysis.edges, analysis.surface, userId ? 1 : 0]
    );

    return NextResponse.json({
      success: true,
      analysis,
      saved: true,
    });
  } catch (error) {
    console.error('Analysis error:', error);
    return NextResponse.json(
      { success: false, error: 'Analysis failed' },
      { status: 400 }
    );
  }
}

// Simulate AI analysis (replace with actual AI service)
async function performAIAnalysis(imageUrl: string): Promise<{
  grade: number;
  confidence: number;
  centering: number;
  corners: number;
  edges: number;
  surface: number;
}> {
  // TODO: Replace with actual AI service
  // For now, simulate based on image analysis
  
  const grades = {
    centering: Math.random() * 10,
    corners: Math.random() * 10,
    edges: Math.random() * 10,
    surface: Math.random() * 10,
  };

  const centeringGrade = getPSAGrade(grades.centering, PSA_CENTRING);
  const cornersGrade = getPSAGrade(grades.corners, PSA_CORNERS);
  const edgesGrade = getPSAGrade(grades.edges, PSA_EDGES);
  const surfaceGrade = getPSAGrade(grades.surface, PSA_SURFACE);

  // Overall grade is the minimum of all subgrades (PSA rule)
  const grade = Math.min(centeringGrade, cornersGrade, edgesGrade, surfaceGrade);
  const confidence = 0.85 + Math.random() * 0.15;

  return {
    grade: Math.round(grade),
    confidence: Math.round(confidence * 100) / 100,
    centering: grades.centering,
    corners: grades.corners,
    edges: grades.edges,
    surface: grades.surface,
  };
}

// Get PSA grade from score
function getPSAGrade(score: number, criteria: typeof PSA_CENTRING): number {
  for (const [name, range] of Object.entries(criteria)) {
    if (score >= range.min && score <= range.max) {
      return range.grade;
    }
  }
  return 5; // Default grade
}
