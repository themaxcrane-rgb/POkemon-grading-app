import { NextResponse } from 'next/server';
import { query } from '@/lib/database';

export async function GET() {
  try {
    // In production, this would use user authentication
    // For now, fetch all analyses (or implement user-specific filtering)
    
    const result = await query(
      `SELECT a.*, u.email, u.username 
       FROM analyses a
       LEFT JOIN users u ON a.user_id = u.id
       ORDER BY a.analysis_timestamp DESC
       LIMIT 100`
    );

    const rows = result.rows || [];

    return NextResponse.json({
      success: true,
      count: rows.length,
      analyses: rows.map((row: any) => ({
        id: row.id,
        cardName: row.card_name,
        setName: row.set_name,
        predictedGrade: row.predicted_grade,
        confidenceScore: row.confidence_score,
        centeringScore: row.centering_score,
        cornerScore: row.corner_score,
        edgeScore: row.edge_score,
        surfaceScore: row.surface_score,
        analysisTimestamp: row.analysis_timestamp,
        isPaid: row.is_paid,
        email: row.email,
        username: row.username,
      })),
    });
  } catch (error) {
    console.error('Failed to fetch analyses:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to load analyses' },
      { status: 500 }
    );
  }
}
