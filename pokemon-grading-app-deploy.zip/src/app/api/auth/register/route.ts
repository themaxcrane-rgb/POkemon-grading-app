import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { query } from '@/lib/database';

const registerSchema = z.object({
  email: z.string().email(),
  username: z.string().min(2).optional(),
  password: z.string().min(8),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { email, username, password } = registerSchema.parse(body);

    // Check if user already exists
    const usersResult = await query(
      'SELECT id FROM users WHERE email = $1',
      [email]
    );

    if (usersResult.rows.length > 0) {
      return NextResponse.json(
        { error: 'Email already registered' },
        { status: 400 }
      );
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Create user
    const userResult = await query(
      'INSERT INTO users (email, username, password_hash, subscription_tier, credit_balance) VALUES ($1, $2, $3, $4, $5) RETURNING id, email, username, subscription_tier, credit_balance',
      [email, username || null, hashedPassword, 'free', 3]
    );

    return NextResponse.json({
      success: true,
      user: {
        id: userResult.rows[0].id,
        email: userResult.rows[0].email,
        username: userResult.rows[0].username,
        subscriptionTier: userResult.rows[0].subscription_tier,
        creditBalance: userResult.rows[0].credit_balance,
      },
    });
  } catch (error) {
    console.error('Registration error:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
