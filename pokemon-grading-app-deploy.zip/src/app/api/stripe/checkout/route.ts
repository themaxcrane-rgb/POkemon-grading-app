import { NextRequest, NextResponse } from 'next/server';
import Stripe from 'stripe';

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY || '');

const prices = {
  monthly: process.env.STRIPE_PRICE_MONTHLY || 'price_monthly_123',
  yearly: process.env.STRIPE_PRICE_YEARLY || 'price_yearly_123',
};

export async function POST(request: NextRequest) {
  try {
    const { subscriptionType } = await request.json();
    
    let sessionId: string;

    if (subscriptionType === 'yearly') {
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price: prices.yearly,
            quantity: 1,
          },
        ],
        mode: 'subscription',
        success_url: `${process.env.NEXT_PUBLIC_API_URL}/dashboard?success=true`,
        cancel_url: `${process.env.NEXT_PUBLIC_API_URL}/pricing?canceled=true`,
        customer_email: (await request.json()).email,
        metadata: {
          subscriptionType: 'yearly',
        },
      });

      sessionId = session.id;
    } else {
      const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        line_items: [
          {
            price: prices.monthly,
            quantity: 1,
          },
        ],
        mode: 'subscription',
        success_url: `${process.env.NEXT_PUBLIC_API_URL}/dashboard?success=true`,
        cancel_url: `${process.env.NEXT_PUBLIC_API_URL}/pricing?canceled=true`,
        customer_email: (await request.json()).email,
        metadata: {
          subscriptionType: 'monthly',
        },
      });

      sessionId = session.id;
    }

    return NextResponse.json({
      success: true,
      sessionId,
      type: subscriptionType,
    });
  } catch (error) {
    console.error('Stripe checkout error:', error);
    return NextResponse.json(
      { success: false, error: 'Failed to create checkout session' },
      { status: 500 }
    );
  }
}
