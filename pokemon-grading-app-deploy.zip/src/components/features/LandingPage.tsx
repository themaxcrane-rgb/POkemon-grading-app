'use client';

import { useState } from 'react';
import { UploadZone } from './UploadZone';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Download, Settings, Info, ChevronRight } from 'lucide-react';
import Link from 'next/link';

export function LandingPage() {
  const [selectedCard, setSelectedCard] = useState(null);
  const [grade, setGrade] = useState(null);
  const [loading, setLoading] = useState(false);
  const [selectedSet, setSelectedSet] = useState('base');
  const [cardName, setCardName] = useState('');

  const handleFileSelect = (files: File[]) => {
    const file = files[0];
    const reader = new FileReader();
    reader.onload = (e) => {
      setSelectedCard({
        file,
        preview: e.target?.result as string,
      });
    };
    reader.readAsDataURL(file);
  };

  const handleAnalyze = async () => {
    setLoading(true);
    // Simulate analysis - in production this would call the API
    setTimeout(() => {
      setGrade(8.5);
      setLoading(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      {/* Header */}
      <header className="sticky top-0 z-50 border-b bg-white/80 backdrop-blur">
        <div className="container mx-auto px-4">
          <nav className="flex items-center justify-between py-4">
            <Link href="/" className="flex items-center gap-2">
              <div className="h-8 w-8 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <span className="text-white font-bold text-sm">P</span>
              </div>
              <span className="font-semibold text-lg">Pokémon Grading AI</span>
            </Link>

            <div className="hidden md:flex items-center gap-6">
              <Link href="#how-it-works" className="text-sm text-gray-600 hover:text-gray-900">
                How It Works
              </Link>
              <Link href="#features" className="text-sm text-gray-600 hover:text-gray-900">
                Features
              </Link>
              <Link href="#pricing" className="text-sm text-gray-600 hover:text-gray-900">
                Pricing
              </Link>
            </div>

            <div className="flex items-center gap-3">
              <Button variant="ghost" size="sm">Sign In</Button>
              <Button size="sm">Get Started</Button>
            </div>
          </nav>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <Badge className="mb-4" variant="secondary">
                🆕 AI-Powered Card Grading
              </Badge>
              <h1 className="text-5xl font-bold mb-6 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Predict Your PSA Grades Before You Grade
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Upload your Pokémon card photo and get an accurate grade prediction.
                Save money and time by knowing if your card is worth grading.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button size="lg" onClick={handleAnalyze} disabled={!selectedCard || loading}>
                  {loading ? 'Analyzing...' : 'Analyze My Card'}
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
                <Button variant="outline" size="lg">
                  View Examples
                </Button>
              </div>

              <div className="mt-8 flex items-center gap-6 text-sm text-gray-500">
                <div className="flex items-center gap-2">
                  <CheckIcon className="h-4 w-4 text-green-500" />
                  <span>Free to try</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckIcon className="h-4 w-4 text-green-500" />
                  <span>No registration</span>
                </div>
                <div className="flex items-center gap-2">
                  <CheckIcon className="h-4 w-4 text-green-500" />
                  <span>3 free analyses</span>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              {selectedCard ? (
                <Card className="overflow-hidden">
                  <div className="relative aspect-[3/4] bg-gray-100">
                    <img
                      src={selectedCard.preview}
                      alt="Pokémon card"
                      className="w-full h-full object-contain"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end p-4">
                      <div className="text-white">
                        <p className="font-medium">Card Preview</p>
                        <p className="text-sm text-gray-300">{selectedCard.file.name}</p>
                      </div>
                    </div>
                  </div>
                  
                  {grade && (
                    <div className="p-4 bg-gradient-to-r from-green-50 to-blue-50 border-t">
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="text-sm text-gray-600">Predicted Grade</p>
                          <div className="flex items-baseline gap-2">
                            <span className="text-4xl font-bold text-green-600">{grade}</span>
                            <span className="text-sm text-gray-500">/ 10</span>
                          </div>
                        </div>
                        <Button size="sm" variant="outline">
                          View Details
                        </Button>
                      </div>
                    </div>
                  )}
                </Card>
              ) : (
                <UploadZone onFilesSelected={handleFileSelect} />
              )}

              <div className="flex gap-4">
                <Input
                  placeholder="Enter card name (e.g., Charizard Base Set)"
                  value={cardName}
                  onChange={(e) => setCardName(e.target.value)}
                  disabled={!selectedCard}
                />
                <select
                  className="px-4 py-2 border rounded-lg bg-white"
                  value={selectedSet}
                  onChange={(e) => setSelectedSet(e.target.value)}
                  disabled={!selectedCard}
                >
                  <option value="base">Base Set</option>
                  <option value="neo">Neo Genesis</option>
                  <option value="gym">Gym Heroes</option>
                  <option value="ex">EX Era</option>
                  <option value="sv">Scarlet & Violet</option>
                </select>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">Why Use Our Grading AI?</h2>
          <p className="text-center text-gray-600 mb-12 max-w-2xl mx-auto">
            Professional-grade analysis powered by advanced computer vision algorithms
          </p>

          <div className="grid md:grid-cols-3 gap-6">
            <Card className="p-6">
              <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <Settings className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Accurate Analysis</h3>
              <p className="text-gray-600">
                Our AI analyzes 4 criteria: centering, corners, edges, and surface defects
                based on actual PSA grading standards.
              </p>
            </Card>

            <Card className="p-6">
              <div className="h-12 w-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <Info className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Detailed Reports</h3>
              <p className="text-gray-600">
                Get a comprehensive breakdown of your card's condition with subgrade scores
                and actionable feedback.
              </p>
            </Card>

            <Card className="p-6">
              <div className="h-12 w-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <Download className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">Save Money</h3>
              <p className="text-gray-600">
                Avoid wasting $15-30 on grading fees for cards that won't get the grade you want.
                Make informed decisions.
              </p>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-4">How It Works</h2>
          <p className="text-center text-gray-600 mb-12">
            Get your grade prediction in under 30 seconds
          </p>

          <Tabs defaultValue="step1" className="w-full max-w-3xl mx-auto">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="step1">Step 1</TabsTrigger>
              <TabsTrigger value="step2">Step 2</TabsTrigger>
              <TabsTrigger value="step3">Step 3</TabsTrigger>
            </TabsList>
            <TabsContent value="step1" className="mt-6">
              <Card className="p-6">
                <h3 className="text-xl font-semibold mb-3">Upload Your Card</h3>
                <p className="text-gray-600">
                  Take a clear photo of your card with good lighting and upload it.
                  Make sure all four corners are visible and the card is flat.
                </p>
              </Card>
            </TabsContent>
            <TabsContent value="step2" className="mt-6">
              <Card className="p-6">
                <h3 className="text-xl font-semibold mb-3">AI Analysis</h3>
                <p className="text-gray-600">
                  Our advanced AI analyzes your card for centering, corners, edges,
                  and surface defects. The analysis takes about 20-30 seconds.
                </p>
              </Card>
            </TabsContent>
            <TabsContent value="step3" className="mt-6">
              <Card className="p-6">
                <h3 className="text-xl font-semibold mb-3">Get Your Grade</h3>
                <p className="text-gray-600">
                  Receive a predicted PSA grade with a detailed breakdown of each
                  subgrade. Decide if your card is worth grading!
                </p>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-gray-900 text-gray-400 text-sm">
        <div className="container mx-auto px-4 text-center">
          <p>© 2026 Pokémon Grading AI. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}

function CheckIcon(props: any) {
  return (
    <svg {...props} xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>
  );
}
