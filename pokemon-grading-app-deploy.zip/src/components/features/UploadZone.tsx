'use client';

import { useCallback } from 'react';
import { useDropzone } from 'react-dropzone';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Upload } from 'lucide-react';

export function UploadZone({ onFilesSelected }: { onFilesSelected: (files: File[]) => void }) {
  const onDrop = useCallback((acceptedFiles: File[]) => {
    onFilesSelected(acceptedFiles);
  }, []);

  const { getRootProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'image/png': ['.png'],
      'image/jpeg': ['.jpeg', '.jpg'],
      'image/webp': ['.webp'],
    },
    maxFiles: 1,
  });

  return (
    <div className="w-full max-w-2xl mx-auto">
      <Card className="p-8 border-2 border-dashed border-gray-300 bg-gray-50">
        <div {...getRootProps()} className="w-full h-64 flex flex-col items-center justify-center cursor-pointer border-2 border-dashed border-gray-300 rounded-lg hover:border-blue-500 hover:bg-blue-50 transition-colors">
          <input type="file" hidden />
          
          <div className="text-center">
            {isDragActive ? (
              <div className="py-12">
                <Upload className="mx-auto h-12 w-12 text-blue-500 mb-4" />
                <p className="text-lg font-medium text-gray-900">
                  Dropping card photo...
                </p>
              </div>
            ) : (
              <>
                <Upload className="mx-auto h-12 w-12 text-gray-400 mb-4" />
                <p className="text-lg font-medium text-gray-900 mb-2">
                  Drag & drop your card photo here
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  or click to browse
                </p>
                <p className="text-xs text-gray-400">
                  Supported: PNG, JPEG, WebP (max 10MB)
                </p>
              </>
            )}
          </div>
        </div>
      </Card>
      
      <div className="mt-4 flex justify-center gap-4">
        <Button variant="outline" size="sm">
          <Upload className="mr-2 h-4 w-4" />
          Browse Files
        </Button>
        <Button size="sm">
          <span className="text-sm">Camera</span>
        </Button>
      </div>
    </div>
  );
}
