-- Setup script for Pokémon Card Grading database
-- Run this after starting PostgreSQL

-- Create user if not exists
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'pokemon_user') THEN
        CREATE ROLE pokemon_user LOGIN PASSWORD 'pokemon_password';
        ALTER ROLE pokemon_user SET client_encoding TO 'utf8';
        ALTER ROLE pokemon_user SET default_transaction_isolation TO 'read committed';
        ALTER ROLE pokemon_user SET timezone TO 'UTC';
    END IF;
END $$;

-- Create database if not exists
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_database WHERE datname = 'pokemon_grading') THEN
        CREATE DATABASE pokemon_grading
        WITH OWNER = pokemon_user
        ENCODING = 'UTF8'
        LC_COLLATE = 'en_US.UTF-8'
        LC_CTYPE = 'en_US.UTF-8'
        TEMPLATE = template0;
    END IF;
END $$;

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE pokemon_grading TO pokemon_user;

-- Connect to database and create tables
\connect pokemon_grading

-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(100) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    subscription_tier VARCHAR(20) DEFAULT 'free',
    credit_balance INT DEFAULT 3,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_login TIMESTAMP
);

-- Create analyses table
CREATE TABLE IF NOT EXISTS analyses (
    id SERIAL PRIMARY KEY,
    user_id INT REFERENCES users(id) ON DELETE CASCADE,
    card_name VARCHAR(255) NOT NULL,
    set_name VARCHAR(255) NOT NULL,
    image_url TEXT,
    predicted_grade INT CHECK (predicted_grade BETWEEN 1 AND 10),
    confidence_score DECIMAL(5,2),
    centering_score DECIMAL(5,2),
    corner_score DECIMAL(5,2),
    edge_score DECIMAL(5,2),
    surface_score DECIMAL(5,2),
    analysis_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_paid INT DEFAULT 0
);

-- Create index for faster lookups
CREATE INDEX idx_analyses_user_id ON analyses(user_id);
CREATE INDEX idx_analyses_card_name ON analyses(card_name);
CREATE INDEX idx_analyses_created_at ON analyses(analysis_timestamp);

-- Grant privileges on tables
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO pokemon_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO pokemon_user;

-- Create a view for user's analyses
CREATE OR REPLACE VIEW user_analyses AS
SELECT 
    a.id,
    u.email,
    u.username,
    a.card_name,
    a.set_name,
    a.predicted_grade,
    a.confidence_score,
    a.analysis_timestamp,
    a.is_paid
FROM analyses a
JOIN users u ON a.user_id = u.id
ORDER BY a.analysis_timestamp DESC;

\connect pokemon_grading

-- Create a view for paid analyses
CREATE OR REPLACE VIEW paid_analyses AS
SELECT 
    a.id,
    a.card_name,
    a.set_name,
    a.predicted_grade,
    a.confidence_score,
    a.centering_score,
    a.corner_score,
    a.edge_score,
    a.surface_score,
    a.analysis_timestamp
FROM analyses a
WHERE a.is_paid = 1
ORDER BY a.analysis_timestamp DESC;
