# Deployment Instructions for Pokémon Card Grading Assistant

## Quick Start

1. **Upload to GitHub:**
   - Create a new repository: `pokemon-grading-app`
   - Upload the `deploy-ready` folder
   - Make sure it's PUBLIC

2. **Deploy to Render (FREE):**
   - Go to https://render.com
   - Click "New +" → "Web Service"
   - Connect your GitHub repository
   - Settings:
     - Name: `pokemon-grading-app`
     - Environment: `Production`
     - Root Directory: `deploy-ready`
     - Build Command: `npm install && npm run build`
     - Start Command: `npm start`
     - Region: `Oregon` (recommended)
   - Click "Create Web Service"

3. **Get Your URL!**
   - Wait ~2 minutes for deployment
   - You'll get: `https://pokemon-grading-app.onrender.com`

4. **Access from Phone:**
   - Open the URL on your phone
   - Your app is live! 🎉

## Troubleshooting

- **Database Error**: Render requires a PostgreSQL database
  - Add a "PostgreSQL" database in Render
  - Update `.env` with the database URL

- **Build Error**: Make sure you're uploading the `deploy-ready` folder, not the root

## Production Setup

After deploying:
1. Update `.env` with your actual Stripe keys
2. Set up a real PostgreSQL database
3. Configure environment variables in Render dashboard

## Support

Need help? Check:
- `README.md` - Project overview
- `PROJECT_STATUS.md` - Current progress
- `GUIDE_FOR_PHONE_ACCESS.md` - Phone access guide
